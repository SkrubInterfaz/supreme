<section class="content-item grey" id="error">
    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-md-8 col-lg-6 col-sm-offset-1 col-md-offset-2 col-lg-offset-3">
                <div class="error-box">
                    <h4 class="card-title"><?=$titre;?></h4>
                    <h6 class="card-subtitle mb-2 text-muted"><?=$type;?></h6>
                    <p class="card-text"><?=$contenue;?></p>
                    <a class="btn btn-block btn-danger" href="index.php">Retour sur la page d'accueil</a>
                    <a class="btn btn-block btn-secondary" href="javascript:history.back()">Retour sur la page précédente</a>
                </div>
            </div>
        </div>
    </div>
</section>
