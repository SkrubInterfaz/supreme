<!-- <script src="https://codeseven.github.io/toastr/build/toastr.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css" rel="stylesheet" type="text/css">
<script>
toastr["error"]("Le mode maintenance a été activé , seul les administrateurs on accès au site internet ! ", "<i class='fa fa-exclamation-triangle'></i>")
toastr.options = {
  "closeButton": true,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-full-width",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "-1",
  "hideDuration": "-1",
  "timeOut": "-1",
  "extendedTimeOut": "-1",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
</script> -->