<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Erreur | Vous n'avez pas access à cette page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="./main.css" />
</head>
<body>

<article>
    <h1>Erreur</h1>
    <div>
        <p>Vous n'avez pas access a cette page !</p>
        <a href="../../../index.php">Retour a l'acceuil du site</p>
    </div>
</article>
</body>
</html>