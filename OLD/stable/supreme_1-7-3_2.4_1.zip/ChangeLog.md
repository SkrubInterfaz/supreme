# Supreme 2.4 

GitHub: [En cours de création]

Auteur de l'adaptation: PinglsDzn#1702 

Contact: [hello@pinglsdzn.eu](mailto://hello@pinglsdzn.eu)

Par: Amjido & PinglsDzn

Version: 2.4_fr

Langue: Français (FR_fr) - French

    >  Note:  
        Le github officiel pour le thème sera bientôt crée

(`Proposé avec au préalable un autorisation de Amjido le créateur original du thème, repris par PinglsDzn pour satisfaire la communauté de CraftMyWebsite.Fr`)

## QUOI DE NEUF ?

|      Définition          |Symbole            |
|--------------------------|-------------------|
|Ajout			           |`"[+]"`            |
|BugFix                    |`"[/]"`            |


[+] Administration Forum 
    (`La zone de création à etait revu pour être plus compréhensible, on commance à arriver à quelque chose de plutôt propre avec deux boutton bien distinct pour ajouté un forum/catégorie et deux autres bouttons pour les paramétres généraux`)

[+] Refonte forum
    (`Le forme générale du forum à etait revu, il y a maintenant deux "colonne" une avec les forums / catégories et l'autre avec des informations sur le profil ainsi que deux addons/modules activable sur la page de configuration du thème !`)

[+] Modules Boutique
    (`La boutique intégre maintenant un système d'addons/modules avec comme addons/modules la prévisualisation du panier, et nouveauté un historique d'achat`)

[+] Tokens
    (`Le nom de la monnaie ainsi que sont icone peux être changer depuis la page configuration du thème !`)

[+] Page configuration
    (`La page de configuration du thème à était refaite, celle-ci et maintenant beaucoup plus compréhensible pour le bien de nous tous (Script de sélécteur de couleur par: http://jscolor.com/ )`)

[+] Vote
    (`La section de vote sur la page voter et en cours d'amélioration, on commance déjà a être de plus en plus proche de la stylisation des autres pages 😁`)

[/] Panier
    (`Correction du titre qui n'était pas correctement stylisé`)

[/] News
    (`Reouverture d'une balise de grille (Sur la version _dev du thème la balise était fermer alors qu'il faut qu'elle soit ouverte, sinon les news ne sont plus dans la grille d'affichage)`)

[/] Offres boutique
    (`Fermeture d'une balise mal fermé qui rendais la page boutique désordoné lorsque le stock d'une offre était épuisé`)

[/] Tabs/Onglet de navigation sur la page profil 
    (`les onglet dit 'tabs' était buggé, Troiséme onglet déplacer dans le deuxieme`)

[/] Image du skin (body) sur la page profil 
    (`Passage de l'api propre à craftmywebsite à une api externe (Minotar) pour l'affichage du skin/body du joueur en attendant d'avoir un patchbug sur l'apiskin de craftmywebsite`)

### Merci à:

> @Florentlife , Mrlog42#6791 , @PandaxCSGO